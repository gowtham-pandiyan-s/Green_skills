from flask import Flask, render_template, request
import numpy as np
import joblib

app = Flask(__name__)

# Load trained Random Forest model and scaler
model = joblib.load("rf_model.pkl")
scaler = joblib.load("scaler.pkl")

# MUST MATCH TRAINING FEATURES (order + count)
FEATURES = [
    'temperature_2_m_above_gnd',
    'relative_humidity_2_m_above_gnd',
    'total_cloud_cover_sfc',
    'shortwave_radiation_backwards_sfc',
    'wind_speed_10_m_above_gnd',
    'angle_of_incidence',
    'zenith',
    'azimuth'
]

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    error = None

    if request.method == "POST":
        try:
            values = []

            # Read values from form
            for feature in FEATURES:
                val = request.form.get(feature)
                if val is None or val.strip() == "":
                    raise ValueError(f"Missing value for {feature}")
                values.append(float(val))

            values = np.array(values)

            # Physical constraint: no radiation → no power
            if values[3] <= 0:
                prediction = 0.0
            else:
                X = values.reshape(1, -1)
                X_scaled = scaler.transform(X)
                prediction = round(float(model.predict(X_scaled)[0]), 2)

        except Exception as e:
            error = str(e)

    return render_template("index.html", prediction=prediction, error=error)

if __name__ == "__main__":
    app.run(debug=True)
