import pandas as pd
import numpy as np

# ==============================
# 1. LOAD DATASET
# ==============================
data = pd.read_csv("dataset\spg.csv")

print("Original shape:", data.shape)

# ==============================
# 2. TARGET SMOOTHING (MAIN NOISE)
# ==============================
data['generated_power_kw'] = (
    data['generated_power_kw']
    .rolling(window=5, center=True)
    .mean()
)

# ==============================
# 3. OUTLIER SUPPRESSION (IQR)
# ==============================
Q1 = data['generated_power_kw'].quantile(0.25)
Q3 = data['generated_power_kw'].quantile(0.75)
IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

data['generated_power_kw'] = data['generated_power_kw'].clip(lower, upper)

# ==============================
# 4. IRRADIANCE SMOOTHING
# ==============================
data['shortwave_radiation_backwards_sfc'] = (
    data['shortwave_radiation_backwards_sfc']
    .rolling(window=5)
    .mean()
)

# ==============================
# 5. CLOUD COVER SMOOTHING
# ==============================
cloud_cols = [
    'total_cloud_cover_sfc',
    'high_cloud_cover_high_cld_lay',
    'medium_cloud_cover_mid_cld_lay',
    'low_cloud_cover_low_cld_lay'
]

for col in cloud_cols:
    data[col] = data[col].rolling(window=3).mean()

# ==============================
# 6. REMOVE NaNs
# ==============================
data = data.dropna().reset_index(drop=True)

print("Cleaned shape:", data.shape)

# ==============================
# 7. SAVE CLEAN DATASET
# ==============================
data.to_csv("spg_cleaned.csv", index=False)

print("✅ Noise reduced dataset saved as spg_cleaned.csv")
